import logging
def get(name='zeph'):
    l=logging.getLogger(name)
    if not l.handlers:
        h=logging.StreamHandler()
        f=logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        h.setFormatter(f)
        l.addHandler(h)
    return l

import logging
def get(name='zeph'):
    l=logging.getLogger(name)
    if not l.handlers:
        h=logging.StreamHandler()
        f=logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        h.setFormatter(f)
        l.addHandler(h)
    return l

import logging
def get(name='zeph'):
    l=logging.getLogger(name)
    if not l.handlers:
        h=logging.StreamHandler()
        f=logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        h.setFormatter(f)
        l.addHandler(h)
    return l

import logging
def get(name='zeph'):
    l=logging.getLogger(name)
    if not l.handlers:
        h=logging.StreamHandler()
        f=logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        h.setFormatter(f)
        l.addHandler(h)
    return l

import logging
def get(name='zeph'):
    l=logging.getLogger(name)
    if not l.handlers:
        h=logging.StreamHandler()
        f=logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        h.setFormatter(f)
        l.addHandler(h)
    return l

